Attention:

On the file Part1.dxf, the red lines should be verified. There are TWO screw sizes for the delrin Z-axis nut (5mm or 6mm) so the red figures should be adjusted to match the screw size on your machine.